# KING APP — GitHub `tsconfig.json` Sync Patch

## Exact Destination
Place `tsconfig.json` at the exact repository root:

`/tsconfig.json`

Overwrite the existing `/tsconfig.json` in `waqaahmad1230-arch/king-app-full` (`main` branch).

## Purpose
Fixes the Vercel Vite 8 build error:
`[plugin:vite:transform] Failed to load tsconfig "/vercel/path0/tsconfig.json" JSONError`

## Validation & Scope
- `tsconfig.json` is validated with `JSON.parse()` prior to packaging (569 bytes, strict JSON).
- Only commit `tsconfig.json` to your repository root (do not overwrite your repository's existing `README.md`, `package.json`, `bun.lock`, `vite.config.ts`, Firebase settings, API keys, or environment variables).
