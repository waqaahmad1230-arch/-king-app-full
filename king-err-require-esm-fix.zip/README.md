# KING App — Verified GitHub Sync Package (`ERR_REQUIRE_ESM` Fix)

This archive contains the **8 verified files** (4 TypeScript source files + 4 rebuilt Vercel CJS bundles) from the approved `ERR_REQUIRE_ESM` root-cause fix.

## Included Source & Bundle Files (Preserve Exact Paths)
1. `api/_lib/authBackend.ts`
2. `api/_lib/cloudinaryConfig.ts`
3. `api/_lib/statusBackend.ts`
4. `server/aiBackend.ts`
5. `api/_lib/aiExecCore.cjs`
6. `api/_lib/authCore.cjs`
7. `api/_lib/statusCore.cjs`
8. `api/_lib/aiStatusCore.cjs`

Package metadata files (do **not** commit to repository root):
- `README.md` (this guide)
- `MANIFEST.json` (file sizes and SHA-256 checksums)

## Upload / Sync Instructions (GitHub `main`)
1. Download `king-err-require-esm-fix.zip` from the project workspace.
2. Extract the archive locally into a temporary folder.
3. Optional: Verify extracted file SHA-256 checksums against `MANIFEST.json`.
4. Copy **only** the `api/` and `server/` directories into your repository root (`waqaahmad1230-arch/-king-app-full`, branch `main`), preserving exact relative paths:
   - `api/_lib/authBackend.ts`
   - `api/_lib/cloudinaryConfig.ts` (new file)
   - `api/_lib/statusBackend.ts`
   - `api/_lib/aiExecCore.cjs`
   - `api/_lib/authCore.cjs`
   - `api/_lib/statusCore.cjs`
   - `api/_lib/aiStatusCore.cjs`
   - `server/aiBackend.ts`
5. Do **not** upload `README.md` or `MANIFEST.json` into the repository root.
6. Commit and push to `main` so Vercel builds and deploys cleanly.

## Post-Deploy Verification
- `GET https://king-app-full.vercel.app/api/post-editor/ai-edit` -> HTTP `200` valid JSON
- `POST https://king-app-full.vercel.app/api/post-editor/ai-edit` (no auth) -> HTTP `401` JSON (`AUTH_REQUIRED`)
- Signed-in AI Edit test in the app -> HTTP `200` valid JSON image response
