# KING APP — Complete GitHub Sync Package (`main`)

## Included Fixes
1. Root `tsconfig.json` — valid strict JSON (fixes `[plugin:vite:transform] Failed to load tsconfig "/vercel/path0/tsconfig.json" JSONError`).
2. Vercel Serverless Cold-Start Isolation — domain-split `.cjs` bundles (`authCore.cjs`, `aiStatusCore.cjs`, `statusCore.cjs`, `aiExecCore.cjs`) built by `scripts/build-vercel-api.mjs` + updated `api/` routes, `vercel.json`, `package.json`.
3. KING AI 3-Error Fixes — Gemini daily RPD/quota project failover (`429`), strict backend JSON normalization (`Content-Type: application/json`, non-200 error codes, malformed body `400`), and safe frontend response parsing in `src/services/postAiService.ts`.

## Exact Target Paths
Extract into repository root (`waqaahmad1230-arch/king-app-full`, branch `main`) preserving exact paths.

Ensure these obsolete files are removed if present on `main`:
- `api/_lib/vercelCore.mjs`
- `api/_lib/vercelCore.d.mts`
- `api/_lib/vercelCoreEntry.ts`

## Build & Verification Commands
```bash
npm run build
npx tsc --noEmit
npx tsc -p api/tsconfig.json --noEmit
```

## Security Notice
This archive contains NO `.env` files, NO `.king-ai-vault*` files, NO API keys, NO Firebase configs, NO `node_modules`, and NO `dist/` artifacts.
